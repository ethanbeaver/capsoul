//Written by Ethan Beaver and Cameron Smith

public class Die {
    private static final int DEFAULT_SIDES = 6;

    private int numSides;
    private int roll = 1;

    public Die() {
        numSides = DEFAULT_SIDES;
    }
    public Die(int num_sides) {
        numSides = num_sides;
    }
    public Die(int num_sides, int initial_roll) {
        numSides = num_sides;
        roll = initial_roll;
    }

    public int roll() {
        roll = 1 + (int)(Math.random() * numSides);
        return roll;
    }

    public int numSides() {
        return numSides;
    }

    public int result() {
        return roll;
    }

    public boolean equals(Die otherDie) {
        return otherDie.result() == roll;
    }

    public String toString() {
        return "Num sides: " + numSides + ", result: " + roll;
    }
}
