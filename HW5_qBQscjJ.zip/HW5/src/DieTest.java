//Written by Ethan Beaver and Cameron Smith

import org.junit.Before;
import org.junit.Test;

public class DieTest {

    private Die die1;
    private Die die2;
    private Die die3;

    @Before
    public void setUp() {
        die1 = new Die();
        die2 = new Die(8);
        die3 = new Die(12, 7);
    }

    @Test
    public void testRollWithinBounds() {
        int roll1, roll2;
        for(int i = 0; i < 100; i++) {
            roll1 = die1.roll();
            roll2 = die2.roll();
            assert(1 <= roll1 && roll1 <= 6);
            assert(1 <= roll2 && roll2 <= 8);
        }
    }

    @Test
    public void testRollCoversValues() {
        int num_sides = die1.numSides();
        boolean[] rolled = new boolean[num_sides];
        for(int i = 0; i < num_sides*num_sides; i++) {
            rolled[die1.roll()-1] = true;
        }
        for(int j = 0; j < num_sides; j++) {
            assert(rolled[j]);
        }
    }

    @Test
    public void testNumSides() {
        assert(die2.numSides() == 8);
        assert(die1.numSides() == 6);
    }

    @Test
    public void testGetResult() {
        assert(die3.result() == 7);
        Die die = new Die(12, 4);
        assert(die.result() == 4);
    }

    @Test
    public void testEquals() {
        Die die = new Die(12, 8);
        assert(!die3.equals(die));
        die = new Die(12, 7);
        assert(die3.equals(die));
    }

    @Test
    public void testToString() {
        String expected = "Num sides: 12, result: 7";
        assert(die3.toString().equals(expected));
        Die die = new Die(12, 4);
        expected = "Num sides: 12, result: 4";
        assert(die.toString().equals(expected));
    }
}